**UPDATE 23/3** We have received over 750 submissions. We are still working diligently to verify each submission and get them posted. As of today, the total amount of reported income lost is $4,285,037. Your stories are heartbreaking but we know them all too well. We appreciate you, we see you, and we love you, Austin. Hang in there.

Lorem ipsum dolor sit amet textarea

* Lorem opsum
* Dolorum lumet
* Situm nulum

# The cancellation of SXSW is financially crushing for local creatives and small businesses. Many have lost gigs and revenue that they were counting on.

## Please help support our community in Austin by **making donations directly to them** using their information listed below.


### Jméno Příjmení
#### Film & commercial production
#### Income Lost: $2300

Feeling it for all of y’all. Keep your heads up 💪

Instagram: [@jmenoprijmeni](https://www.instagram.com/rello.coffee/)

Web: [shop.rello.cz](http://shop.rello.cz/)
